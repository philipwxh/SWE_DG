# ESDG2D
High order entropy stable DG code for 2D Euler on triangular meshes
